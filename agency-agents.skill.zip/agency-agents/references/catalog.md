# Agency Agents — Catálogo Completo

Fuente: [github.com/msitarzewski/agency-agents](https://github.com/msitarzewski/agency-agents)
147+ agentes across 12 divisiones. MIT License.

---

## 🔧 Engineering (7 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Frontend Developer** 🖥️ | `engineering-frontend-developer.md` | React/Vue/Angular, UI implementation, responsive design, performance optimization, accessibility |
| **Backend Architect** 🏗️ | `engineering-backend-architect.md` | System design, APIs, databases, microservices, scalability, security architecture |
| **Mobile App Builder** 📱 | `engineering-mobile-app-builder.md` | iOS/Android, React Native, Flutter, mobile UX patterns, app store deployment |
| **AI Engineer** 🤖 | `engineering-ai-engineer.md` | ML models, NLP, computer vision, AI integrations, prompt engineering, fine-tuning |
| **DevOps Automator** ⚙️ | `engineering-devops-automator.md` | CI/CD, Docker, Kubernetes, cloud infrastructure, monitoring, IaC |
| **Rapid Prototyper** ⚡ | `engineering-rapid-prototyper.md` | MVPs, quick iterations, proof of concepts, hackathon-speed development |
| **Senior Developer** 👨‍💻 | `engineering-senior-developer.md` | Code review, architecture decisions, mentoring, technical debt, best practices |

---

## 🎨 Design (8 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **UI Designer** 🎨 | `design-ui-designer.md` | Visual design, color theory, typography, design systems, Figma/Sketch workflows |
| **UX Architect** 📐 | `design-ux-architect.md` | Information architecture, user flows, wireframing, interaction design |
| **UX Researcher** 🔍 | `design-ux-researcher.md` | User interviews, usability testing, surveys, personas, journey mapping |
| **Brand Guardian** 🛡️ | `design-brand-guardian.md` | Brand consistency, style guides, tone of voice, visual identity protection |
| **Visual Storyteller** 📸 | `design-visual-storyteller.md` | Visual narratives, infographics, data visualization, presentation design |
| **Image Prompt Engineer** 🖼️ | `design-image-prompt-engineer.md` | AI image generation prompts, Midjourney/DALL-E/Stable Diffusion optimization |
| **Whimsy Injector** ✨ | `design-whimsy-injector.md` | Micro-interactions, delightful details, Easter eggs, playful UX elements |
| **Inclusive Visuals Specialist** 🌍 | `design-inclusive-visuals-specialist.md` | Inclusive imagery, diverse representation, cultural sensitivity in design |

---

## 📢 Marketing (8 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Growth Hacker** 📈 | `marketing-growth-hacker.md` | Growth experiments, viral loops, referral programs, conversion optimization |
| **Content Creator** ✍️ | `marketing-content-creator.md` | Blog posts, newsletters, copywriting, content strategy, SEO writing |
| **Twitter/X Engager** 🐦 | `marketing-twitter-engager.md` | Twitter strategy, thread writing, engagement, community building on X |
| **TikTok Strategist** 🎵 | `marketing-tiktok-strategist.md` | Short-form video strategy, trends, hooks, TikTok-native content |
| **Instagram Curator** 📷 | `marketing-instagram-curator.md` | Visual content strategy, Reels, Stories, feed aesthetics, hashtag strategy |
| **Reddit Community Builder** 🤝 | `marketing-reddit-community-builder.md` | Subreddit engagement, authentic community participation, Reddit marketing |
| **App Store Optimizer** 📲 | `marketing-app-store-optimizer.md` | ASO, keyword optimization, screenshots, A/B testing listings |
| **Social Media Strategist** 📊 | `marketing-social-media-strategist.md` | Cross-platform strategy, content calendars, analytics, audience growth |

---

## 📦 Product (3 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Sprint Prioritizer** 🎯 | `product-sprint-prioritizer.md` | Backlog grooming, sprint planning, feature prioritization, stakeholder alignment |
| **Product Trend Researcher** 🔭 | `product-trend-researcher.md` | Market analysis, competitive intelligence, trend spotting, opportunity mapping |
| **Feedback Synthesizer** 🗣️ | `product-feedback-synthesizer.md` | User feedback analysis, NPS, feature requests, pain point identification |

---

## 📋 Project Management (5 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Project Shepherd** 🐑 | `pm-project-shepherd.md` | Project planning, timeline management, risk mitigation, stakeholder communication |
| **Experimentation Lead** 🧪 | `pm-experimentation-lead.md` | A/B testing, experiment design, statistical significance, feature flags |
| **Ops Coordinator** 🔄 | `pm-ops-coordinator.md` | Cross-team coordination, process optimization, operational efficiency |
| **Production Manager** 🏭 | `pm-production-manager.md` | Release management, deployment coordination, rollback procedures |
| **Scrum Master** 🏉 | `pm-scrum-master.md` | Agile ceremonies, team velocity, impediment removal, retrospectives |

---

## 🧪 QA & Testing (7 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **QA Engineer** 🔎 | `qa-engineer.md` | Test planning, manual/automated testing, bug reporting, regression testing |
| **Performance Analyst** ⏱️ | `qa-performance-analyst.md` | Load testing, performance benchmarks, bottleneck identification, optimization |
| **API Tester** 🔌 | `qa-api-tester.md` | API contract testing, endpoint validation, integration testing, Postman/Newman |
| **Reality Checker** ✅ | `qa-reality-checker.md` | Production readiness verification, edge cases, real-world scenario validation |
| **Security Engineer** 🔒 | `qa-security-engineer.md` | Penetration testing, vulnerability assessment, security audits, OWASP compliance |
| **Accessibility Auditor** ♿ | `qa-accessibility-auditor.md` | WCAG compliance, screen reader testing, keyboard navigation, a11y best practices |
| **Test Automation Architect** 🤖 | `qa-test-automation.md` | Test framework design, CI integration, end-to-end testing, test infrastructure |

---

## 🏢 Operations & Support (6 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Support Responder** 💬 | `ops-support-responder.md` | Customer support, ticket triage, knowledge base, escalation procedures |
| **Data Analyst** 📊 | `ops-data-analyst.md` | Analytics, dashboards, KPI tracking, data storytelling, SQL/Python analysis |
| **Finance Advisor** 💰 | `ops-finance-advisor.md` | Budgeting, forecasting, financial modeling, unit economics, runway planning |
| **Legal Advisor** ⚖️ | `ops-legal-advisor.md` | Terms of service, privacy policies, compliance, contract review, IP guidance |
| **Executive Reporter** 📋 | `ops-executive-reporter.md` | Board decks, executive summaries, OKR reporting, strategic communications |
| **HR & Culture** 👥 | `ops-hr-culture.md` | Hiring, onboarding, team culture, performance reviews, remote work policies |

---

## 🎮 Game Development (5+ agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Unity Developer** 🎮 | `gamedev-unity.md` | Unity/C#, game mechanics, shader programming, asset optimization |
| **Unreal Developer** 🎮 | `gamedev-unreal.md` | Unreal Engine, Blueprints, C++, level design, cinematic tools |
| **Godot Developer** 🎮 | `gamedev-godot.md` | Godot Engine, GDScript, 2D/3D game development, scene management |
| **Game Designer** 🎲 | `gamedev-game-designer.md` | Game mechanics, balance, player psychology, monetization, GDD writing |
| **Narrative Designer** 📖 | `gamedev-narrative-designer.md` | Interactive storytelling, dialogue systems, world-building, branching narratives |

---

## 🥽 Spatial Computing (6 agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **XR Interface Architect** 🥽 | `spatial-xr-architect.md` | Mixed reality UI/UX, spatial interaction patterns, 3D interface design |
| **VisionOS Developer** 🍎 | `spatial-visionos.md` | Apple Vision Pro, SwiftUI spatial, RealityKit, visionOS-native apps |
| **WebXR Developer** 🌐 | `spatial-webxr.md` | WebXR API, A-Frame, Three.js VR/AR, browser-based immersive experiences |
| **Metal/Graphics Engineer** 🔧 | `spatial-metal.md` | Metal API, GPU programming, shaders, rendering pipelines, graphics optimization |
| **Vision Pro UX** 👁️ | `spatial-visionpro-ux.md` | Vision Pro interaction patterns, eye tracking, hand tracking, spatial audio |
| **3D Asset Pipeline** 🏗️ | `spatial-3d-pipeline.md` | 3D asset optimization, USD/USDZ, reality conversion, asset management |

---

## 🎓 Academic (3+ agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Research Analyst** 📚 | `academic-research-analyst.md` | Literature review, research methodology, academic writing, citation management |
| **World-Builder** 🌍 | `academic-world-builder.md` | Fictional world creation, lore consistency, cultural systems, geography design |
| **Narrative Analyst** 📖 | `academic-narrative-analyst.md` | Story structure analysis, thematic analysis, comparative literature |

---

## 💰 Paid Media (3+ agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **PPC Specialist** 🎯 | `paid-ppc-specialist.md` | Google Ads, search campaigns, keyword strategy, bid management, ROAS optimization |
| **Paid Social Manager** 📱 | `paid-social-manager.md` | Facebook/Instagram/TikTok ads, audience targeting, creative testing, funnel optimization |
| **Programmatic Buyer** 🤖 | `paid-programmatic.md` | DSP management, RTB, audience segments, viewability, brand safety |

---

## ⚡ Specialized (6+ agentes)

| Agente | Archivo | Especialidad |
|--------|---------|-------------|
| **Multi-Agent Orchestrator** 🎭 | `special-orchestrator.md` | Coordinating multiple agents, task decomposition, cross-division workflows |
| **Data Analytics Engineer** 📊 | `special-data-analytics.md` | Data pipelines, ETL, data warehousing, dbt, analytics engineering |
| **Sales Strategist** 🤝 | `special-sales-strategist.md` | Sales process, CRM strategy, pipeline management, closing techniques |
| **Distribution Strategist** 🚀 | `special-distribution.md` | Go-to-market, channel strategy, partnership development, market entry |
| **Cultural Intelligence Strategist** 🌐 | `special-cultural-intelligence.md` | Localization, cultural adaptation, global market sensitivity |
| **Pricing Analyst** 💲 | `special-pricing-analyst.md` | Pricing strategy, competitive pricing, value-based pricing, A/B price testing |

---

## Cómo activar un agente

El usuario puede decir cualquiera de estos:
- "Activa el Frontend Developer"
- "Modo Backend Architect"
- "Quiero al Growth Hacker"
- "Usa el agente de QA"
- "Necesito un UX Researcher"
- "Sé mi Project Shepherd"
- O simplemente describir una tarea y dejar que se sugiera el agente adecuado
